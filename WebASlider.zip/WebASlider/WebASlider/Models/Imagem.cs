﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebASlider.Models
{
    public class Imagem
    {
        public string descricao { get; set; }
        public string url { get; set; }
    }
}
