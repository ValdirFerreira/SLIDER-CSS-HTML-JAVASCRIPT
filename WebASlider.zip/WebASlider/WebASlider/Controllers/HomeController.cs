﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebASlider.Models;

namespace WebASlider.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [HttpGet("/api/ListaImagens")]
        public async Task<JsonResult> ListaImagens()
        {
            var listaImagens = new List<Imagem>();

            listaImagens.Add(new Imagem
            {
                descricao = " Essa e a Primeira Imagem",
                url = "/img/IMG_8028.JPG"
            });
            listaImagens.Add(new Imagem
            {
                descricao = " Essa e a Segunda Imagem",
                url = "/img/IMG_8029.JPG"
            });
            listaImagens.Add(new Imagem
            {
                descricao = " Essa e a Terceira Imagem",
                url = "/img/IMG_8030.JPG"
            });
            listaImagens.Add(new Imagem
            {
                descricao = " Essa e a Quarta Imagem",
                url = "/img/IMG_8031.JPG"
            });

            return Json(listaImagens);

        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
